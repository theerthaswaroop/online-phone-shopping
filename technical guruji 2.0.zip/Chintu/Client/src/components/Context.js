import React, { Component } from 'react'

export const DataContext = React.createContext();

export class DataProvider extends Component {

    state = {
        products: [
            {
                "_id": "1",
                "title": "Samsung  S10,S10+",
                "src": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAwJCRUNEhANDQ0QDQ0NEBUQEA0QDxoPEQ0WLR0lIyAdICAmLTwyJio4Kh8gPkk/OT5AREVQMDxMUktCUj1DREEBDQ4OExEUJhUVJUUnLCdHQUFBQUVBRkFOQU5BTkFBQUFFQUFBRU5BTUFOQUVBQkVBQUFNQUFBRUFBQUFNQUFBQf/AABEIAOIA3wMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAAAQIDBAUGBwj/xABJEAABAwEDAw8ICAUEAwAAAAABAAIDEQQhMQUScQYTFTIzQVFUYXN0k7Gy0RQicoGRobPBFyNSU5TC0uEHFkJE8CQ0Q5JiY8P/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQIDBAX/xAAoEQACAgEDAwQCAwEAAAAAAAAAAQIRAwQxQRIhMhMUUWEi8CMzgQX/2gAMAwEAAhEDEQA/APQatNVU2T82zZPjD7Q40c4guzTSoAGjHTiF4z+YcskV12Nld4yOdT2kr0+qFgM1ofidec0HgGYwEe4LhELpx4VJWzzdTrJ459EUuxjOqHLA/uYv+xUDqlywP7mL2rVI1Z3ha+3gYrW5fr9/0qOqrK4/uI/afFQ/mvKzRfaGkD1n2lD4lSWKvbQNVq5v4Ljqwyrxge1I6scq8YHtWV8SrMaXtoGq1Mmazq1yrxhvv8Uv52ypxhvv8VgdEqzGl7eJazs6f875U4wPf4pfzzlQf3A9/ivPztIca54FBmZuBuNQeWtFnFa351N/houaSinVM6IttWe0yd/EPKEUrNeLJWFwDs4uIIrykgDQBpX2OwWwWqKOdoLc8ec04sdWhadBBX51sgNW1riaVxpyr7zqYP8ApiOCU+olrSfeSlOFJP5CMrbXwb8oWl0DBrTA+aR2txMOBcd88gAJKwQWKaTzp7XKXb+tuMbRoANPcuhO0GSKv9LJHDTcOwlOA3HSsyzPsaeNT9YUbGnjU/WLZVGcpsrpMexp41aOsS2NPGp+sK3ZyKosKMWxh4xP1hRsYeMTdYVtqnVMKMByWTT/AFU9xrdKQnsaeMT9YVuqnVMVGDYw8Ym6wo2MPGp+sK3VTBQFHLnyfI0VjtcwIwrI4j1it6sybaZC51ntWaZWtz2StFBOytK03iDSulbZTcVmYBnwv3/rGDRQH5JvYnk8hl8fWT9Id3WLhlq7uXBWS0dIf3WLjlq7cXijw9X/AGyMzmqpzFrLVAsWy7nNZgLVVLFvrdJGqQN6l62SKUjCWcirLRwFbHxFVmMqqNVMyFnIVAxngWl0fL71AsO8UmWpGQx8irMS3kHfAKgQDiCFmy1kaMccXnt0r7ZqY/27+e/I1fHmRecKXiq+x6mdwk549xq4tRsju00uqzoTbrHzUva1QiNx0qc+6x81L2tVcRx0rl4Z2LctqiqjVcDLerCyZKkEFpfI6YtDiyNmcWjeJ4FmaPsehBTBXivpNsPBaep/dH0n2H7Fp6keKdMVo9tVMFeJ+k+w/YtPU/uj6T7B9i09SPFOmK0e2qiq8T9J9g4LT1P7o+lCwfZtPUfumKz2tU6ryWTv4hWG2Sss7XyxSSuDWa7HmtccAKr1lUybIym4qtmMHpP7qlKbioM20HpP7qp7ELc8lljdLR0l/dYuQWrpWsVNp6daO0LFmrqxP8UePql/KyotVZatOaouauiLOKRmcyqzvjFd9bC1UuauiJKZie071VnewnhXT1qqTrOBiqtGizJHJLKKJC3viCpMKhs1U+TIQok8IB9xWsxKt0SzbQ+pFMTRnCnDgvrmplwMMwGLZzUcHmNK+URx+cNK+paldpaukj4bFx6nZHoaN25HWnI12Mb+syn1Vaqot/SpT/7iPo8va1Qj39K5Pk9BblpXxDVuScq22t9HxtHINbaae8r7dVeJ1UahDlS0G2wWhsD3tAka9hc11BQHEX0pvqUaS7nyueNrc3NeHVaCaV83kPLoVYXu/otn4/F1J/Uj6LJ+Pw9Sf1K7RFHiZ4hGG0e12cM6jTXNFTQHerdVUtxFcKitMaL3n0WWjj8XUn9SPorn4/F1J/UixHh52gE5tc0nza0rTlXZOT7Hsb5Tr7fLc3a68M/PrtczgpyYXrvn+Fdo4/F1J/Uj6KZ+PQ9Sf1JPuC7Hm8qykmzHzaxyANLBQi8H2r7y03DQvnFg/hrIJopbZbmzRQvDwwMIzqEGhqTdd/mC+j1TJbIym4pM21n9J/dKUhuKrdtrLzj/AIbk3sTHc8pO2rrT06ftCzhi2ObV1q6dP2hQDFvB9jz9RC5tmYtUHNWwxqlzF0RZwzgzG4KBatRYqy1bqRz0Zs2iZbVWlq0xQgjlQ5UJxt0jALOTvINiPAuoIqJuAWUshosT5Zw5LJRUmBdyRlVlkgUdZMoyX2cpsHnDSvo+piOkdodXb2k3cHmNC8Q2Hzgvd6ndyn6U/utWOd2kel/zW25X9G6dv10bv/TKPe1VRnHSrp91j5qXtaszDjpK5lyeuty1CjVLOUUak1JV1TDk6JZIFNQzk6pkslVCjVFVRDZKqVVGqM5MkJMCoHbWXnH/AA3JvNxS/qsvOv8AhuSlsEdzgPhzX2tta/6yR1aUxANPeoiNaZR9Za+lO7jUNCOqiZY+pmYxqp8a3OCpc2q1jM5MmFIwujVLmVXRfEVneyi6IzOGeMxkNbea+paoSJGtLRjUCtxqFS6Oq0xExwtIAzs9zRVoddjUA6VctiMUabssMEn2CBy+aPaVEWZ191d+4g9iiyZ76CoABrRkbQK8tFoZM9taZt/2ySfcSsZWbx6X8mR7KY3Kgtqt07i4EnNArg0OB0kgUKzOAAr4KKJlEqEV4XrNT25z9Kf2NXmmgXby9Nqf2lo6XJ2NUZGdmijTZttG6x81L2tWZhx0labRusfNS9rVkYcdJWSPRW5IlKqRKQKDQmCjOUQpZp4MBU6E6JbCqdUs08B3j6kZp4P8wTohjqiqKH7KRBGKdEMKpgqKAUyBvNym1tXWb/xkedP1ZHzVTzcr4sbP6T+6VMth49zz9nJLrYTUny6cX8FQB7gFcFVZWkOtgIIPl85vFLqgg+wgrQAsW+50pECKphimQhOxLGr7lTmqh0VVqIQGLSMmiZ4VLsZTZgh8Nc2uDRc3e5fWthCiQto5Gc+XSxrsYi2lwuCAQFOe7BZi5a7nmy/F0XG0AbyzukbU+YaEf0mhad40N3y9ii8KmmcaC8mlKX3qGqJeR8l4pUNGFKtO9TgHsN3gV6TU9udo6XJ2NXkmvLbgDUPzqGoNRcRyEgEL12p/c5+lyU9jVjM7dJuzdaN0j5qXtasTd/SVstG6x81L2tWFp22lTE7mMlKqCkmXZNp7VZruN2ON+NxHzVKKoIZcZbqU3gOxPXb604N/lqqaoTomyzXTSlODtqk51eRV1TqnRDY6pgqFUVTIZKTBTziDZedeD1blU83K0Ak2XnX16tyiexePdnMG6WzpZ7jVMBRbult6We41TC5ZupHfjjcQRRCE0x9IqKdEgpUWlhREBBYrQFZmJqVA6a7nMtLKLnPK7k8Oe0hcXWjnFuFMV245Jo8HWYnCfbki0C+uACH2+RgoyRzQbs0UoeSlL1cyA0d7FRJG4EljASBQuO8N/C+l2hDabMOmaXbsZZSZCXHODiPPpXOB3nAcINK/svXanDWKY3X2l5uuGDV4a2210LMwBuvz1hbeHZgO2JAOFCPWeRe51OCkUwJJItLwScSaNWGTsdmjum2dC0bpHzUva1YAdtpK3T7rHzUva1c8G92kqI8nbLgZSqglKqZTJJqNUVTIZJKqVUVTIY6oqokoqmSyVUAqNUwUyQeblrhxs/pP7pWJ5uWyDGz+k/ulRM0x7s5Td0tvSz3GqSizdLb0s/DapFcWTyPTxeKHVCSKpJmjRIKSgEyVomT0kw5Wses9U2lVuQ4m4vb9g+0BUtYzPrmAZ1zi7zqjgwuSB5VW8morSm+U+l8MxlS3VmC0TNhEjTusdRQDA715up2BcE5Wa9+YI3ObfWZpOtk1xAp5wu3vYa1XSyhE4OaZavY41BN7OEilbqXcFVxi3Af0xkta37Irh7guzHGlZ4+qzNy6Eqr92/fpl9psom+sJAIb9QSAGkG8muNagerexXsdTu5TVx8qfXTRq8VE68N3q3cH+Xr22p3cpulSdgUZEXo5dTZutG6x81L2tXOGLtK6Fo3WLmpe1q54xdpWcTtlwIlIFBSVUKyVUqoRVMgE0kJiBOqSEyWFUBCAgQPNy2wY2f0n90rC/BbocYPSf3VE9jTHuzlR7rbuln4bVIhRj3W3dLPw2q1ceTyPUxeCIgKNFOiZbW9QjWyIKCghRzkwqySAkCglWDRaH3JOkBw31UCq8wg3OPrxWsae5yZPUi1StEbU3OaRjS8V4cKXrjmyAuDakF+0la05mfSpa6ouvu7CcF1pDhncIIApecRjy0KkIgQK3HG66t93rHCtI5KRzZdL6krr9+Dz7B54qF7PU9uc/SpOwLivsTS6odmmvqXbyAKR2gcFrlHYnKSlsZYsEsV9XJstG6xc1L+VcwYu0ldO0bpHzUv5VzN92lKBc+AJUUEoVksKphRqiqCSSajVFUxWNFUqpVTJJJgqFUwgBvwW6HGD0n91YXYLfBjZ9L+6onsa4+TkNP1tt6WfhtVgKq/5bb0s/DapBy4snkephX4IuF6daKsFWB3CpRT7AaFVuYpkUwQSqBMoTUyFWWoNLESglRLOVCpASqOAad9FVWFNMzasYxC6OQdpaOmS/Jc4C8LpZB2lp6ZL8lcGc+dUkarTusXNTflXMOLtJXTtO6x81N+Vcs4u0laxOOfAihIqKsgkhJSTENJJNMQJqKaBAmFFSCBoZwW6DGD0n91YTgt0GNn0v7qznsaQOQN1tvS//m1OiX/Lbeln4bU1xZPJnqYfBACphyjRLBTsalocpEqkOUgU0yaJEqtwU6qBVAiBYkGqZCjRMsAFJRRVFANuIXRyBtLT0yX5LnNN4XRyDtLT0yX5LWByang12ndYuam/KuWcXaSuraN0j5qX8q5bsTpWsDhnwQKipOSWhAgpBATQIEJoTASE0IFQJhIJhIpDOC2wYwek/urGRctkOMHpP7qiexpE453W29KPw2Iqkd1tvSj8NidVxZPJnp4PBDDlMFV1QoNaJkJUSzkByYiVU6qNUi5UFEiokpEoJVAFUiUiUimVRIG8Lp5A3O0dLl+S5QxC6uQNzn6VL8lpA5NVsjZaN0j5qX8q5bsTpXUtG6R81L+Vcw4nStocnBPgrKQUigBWQFE0ITECAhACACiE0UQAUTASUwkWkBWyHbQ6X9iyFa4dtBpf2LOexaOK7dbb0o/Dakm/dbb0o/Daoriy+TPTweCGiqEqqTYlVRqhFUwHVFVFCtBRKqVUkqqgJJJEpIHRIYrrZA3O0dLl+S5LcQuvkHaT9Kl+S0gcer2RrtG6R83L+Vcwi86V07RukfNy/lXOOJ0law5PPnwVEIUnBJaEAgBACkmIKIohNACQhNIaCiYRRMJGiGVqh20PpSdizFaYdtBpf2KZbFHn32gC122zkgSGbXGg4uGYytNFQrCuN/ETU/aZHR5QycHl7DnP1txbJE6lM4chAFdHKvFx5Yy00UDbQ8cJsjXe/NXNPG5O0dWLOoxpn0yqKr5qMu5aNaRymhoaWNpoeDBGzeW/upvwTf0pekzb3MPs+k1Qvm+zeW/upvwbfBLZrLf3U34Nvgj0mHuofZ9JSqvnGzWW/upvwbfBGzOW/upvwbfBP02HuofZ9GTXzfZrLf3U34NvgjZrLf3U34Nvgq6GHuYfZ9HQvnGzWWvupvwLf0pDLeWjWkcxoaGljaaHgwR0MPcw+z6OZBGDI8hrWguc5xoGilSSeBdfU1KJYJJRhJaJHCvqXx9sOVsrSR2aZk7mOeCYiwQMpXEgAVA4TWi+2ZJsPkdnis9Q5zQS9wwc8mrj7SVSVHNny+pVcErS6kkXLHKB7Gn5LnnE6St+UYnuYHwgGaF2uMaTQPuoW15QSuDHlQOcWmORkg28T2EOYeA3LSLOaSs2lRoqTbG1ANxOANxKflI5VoRTL0BUeUjlT8pagVMvSVXlTeVHlTUwouAUlR5UEeVBSUkXAKVFR5W1Ly1lQK3nAb50ILNJWiJ3nwDfOuO9VAPmFyp8psjFSHf9SV0MltfKfKZo3RDMzIYnXPDa1LjwE0CiQzrLLJYYZCS+zwvPC6Jrj2IQpAWxln4pZ+oZ4I2Ms/FLP1LPBCEAGxln4pZ+oZ4I2Ms/FLP1DPBCEAGxln4pZ+oZ4I2Ms/FLP1DPBCEAGxln4pZ+oZ4I2Ms/FLP1DPBCEAGxln4pZ+oZ4I2Ms/FLP1DPBCEAXxxNj82NjWDga0NHuViEIAFTLZo5aa7FHJTDPYHU9qEIAq2Ms/FLP1DPBGxdn4pZ+oZ4IQgA2Ms/FLP1LPBGxsHFIOpb4JISAmMnwjCzQjRE0fJPyCHi0PVN8EIQBHY6DisHUt8EbHQcVg6lvghCYA6wQkAGzQkDAa02g9yWxsHFIOpb4JISAsjsUUbs6OCJjvtNja0+5aEITA//2Q==",
                "description": "Add to Cart to See More!!!",
                "content": "Triple rear camera setup: 16MP with f2.2 aperture ultra wide + 12MP with f1.5 and f2.4 aperture wide + 12MP f2.4 tele| 10MP f1.9 front facing camera 15.51 centimeters (6.1-inch) Dynamic AMOLED multi-touch capacitive touchscreen with 3040 x 1440 pixels resolution 550 ppi pixel density  Memory Storage and SIM 8GB RAM | 128GB internal memory expandable up to 512GB | Dual SIM (nano+nano) dual stand by (4G+4G) Android Pie v9.0 operating system with 2.7GHz + 2.3GHz + 1.9GHz Exynos 9820 octa core processor 3400mAH lithium-ion battery The large notch-free display is a visual treat on the eyes",
                
               
                
                
                "price": 41999,
                "colors":["red","black","crimson","teal"],
                "count": 1
            },
            {
                "_id": "2",
                "title": "iPhone 12",
                "src": "https://images.macrumors.com/t/OPSyMWSCe37pC7WFgm3HcSDpUvA=/400x0/filters:quality(90)/article-new/2019/10/iphone12lineuproundup.jpg?lossy",
                "description": "Add to Cart to See More!!!",
                "content": "6.1-inch Super Retina XDR display,Ceramic Shield, tougher than any smartphone glass,A14 Bionic chip, the fastest chip ever in a smartphone,Advanced dual-camera system with 12MP Ultra Wide and Wide cameras; Night mode, Deep Fusion, Smart HDR 3, 4K Dolby Vision HDR recording,12MP TrueDepth front camera with Night mode, 4K Dolby Vision HDR recording,Industry-leading IP68 water resistance,Supports MagSafe accessories for easy attach and faster wireless charging,iOS with redesigned widgets on the Home screen, all-new App Library, App Clips and more.....",
                "price": 84999,
                "colors":["red","crimson","teal"],
                "count": 1
            },
            {
                "_id": "3",
                "title": "Google Pixel 4a 5G(model)",
                "src": "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcRnlA1klCXPEsrKmBDeriwjIwIHxQBIKmDsGEEY6l-6xQ3SSm7iYKXM6p-pnnA0Ggg072nMx6czru8&usqp=CAc",
                "description": "Add to Cart to See More!!!",
                "content": "Take photos like a pro. With features like HDR+, Night Sight, and more, the Pixel 4a camera takes incredible photos,The Adaptive Battery learns from your favourite apps and reduces power to the ones that you rarely use,5G capable cell phone gives you an extra boost of speed[2] so you can download a movie in seconds,[3] enjoy smooth streaming in ultra clear HD, play games at home and on the go,[4] and even share your 5G speed with friends,The all day battery can last up to 48 hours with Extreme Battery Saver.Take vibrant photos on your phone even in the dark with Night Sight, bring studio-quality light to your pictures of people with Portrait Light; and get more scenery and people in the shot with the rear-facing ultrawide lens",
                "price": 37999,
                "colors":["lightblue","white","crimson","teal"],
                "count": 1
            },
            {
                "_id": "4",
                "title": "Nokia 9 Pure View",
                "src": "https://static.techspot.com/images/products/2018/smartphones/org/2019-02-25-product.png",
                "description": "Add to Cart to See More!!!",
                "content": "A revolutionary, next generation camera with an incredible five cameras and Zeiss Optics complete with two color sensors that provide accurate vibrant color images and three panchromatic sensors that allow the array to collect up to 10-times the amount of light resulting in sharp, incredibly atmospheric still shots with blur effects and Google Photos integration alongside rich and vibrant UHD 4K HDR video with spatial audio capture. Exceptional detail and dynamic range for exceptional photography with control over every element of your image starting with incredible detail and texture from all 5 cameras that automatically adjusts the exposure across the scene or allows for complete control down to the smallest detail with the custom build Pro camera UI. Images can be saved as “raw” DNG format images with unparalleled dynamic range, details and low noise that can be edited directly on your Device with Adobe light room for advanced editing control, retaining the dynamic range that you would ordinarily lose in a jpg. Pure, secure and up-to-date Android free from bloat ware with no skins and no UI changes and years of Android monthly updates. – it’s all part of the Android One family. Built to protect everything that makes it great with a resilient and durable 6000 Series aluminum chassis, that houses a next generation Qualcomm Snapdragon 845 mobile platform and imaging co-processor complete with Qualcomm Bluetooth audio, and integrated Qi wireless charging. Premium design and performance featuring an edge to edge Ultra slim Gorilla glass 5. 99”Qhd 2K LED display enhanced with pure display and HDR10 support lets you enjoy latest content with crisper details, greater contrast and richer colors with integrated under screen fingerprint sensor.",
                "price": 31999,
                "colors":["orange","black","crimson","teal"],
                "count": 1
            },
            {
                "_id": "5",
                "title": "One Plus Nord",
                "src": "https://image01.oneplus.net/ebp/202007/06/1-m00-15-d2-rb8lb18cw9kapfouaawjvqw4rbo469_840_840.png",
                "description": "Add to Cart to See More!!!",
                "content": "48MP+8MP+5MP+2MP quad rear camera with 1080P Video at 30/60 fps, 4k 30fps | 32MP+8MP front dual camera with 4K video capture at 30/60 fps and 1080 video capture at 30/60 fps.6.44-inch 90Hz fluid Amoled display with 2400 x 1080 pixels resolution | 408ppi.Memory, Storage & SIM: 8GB RAM | 128GB internal memory | Dual SIM (nano+nano) | OnePlus Nord currently support dual 4G SIM Cards or a Single 5G SIM. 5G+4G support will be available via OTA update at a future date.OxygenOS based on Android 10 operating system with 2.4GHz Kryo 475 Prime + 2.2GHz Kryo 475 Gold + 6x1.8GHz Kryo 475 Silver Qualcomm Snapdragon 765G 5G Mobile Platform mobile platform octa core processor, Adreno 620 GPU.4115mAH lithium-ion battery | In-Display fingerprint sensor.Box also includes: Screen protector (pre-applied), Warp Charge 30 power adapter , Warp Type-C cable (Support USB 2.0), Quick start guide, Welcome letter, Safety information and warranty card, Brand sticker, Phone case, SIM tray ejector, Highest SAR value & Plastic recycling card, Red Cable Club Membership card.",
                "price": 29999,
                "colors":["orange","black","crimson","teal"],
                "count": 1
            },
            {
                "_id": "6",
                "title": "Moto Razr Folldable Phone",
                "src": "https://i1.wp.com/gadgetpilipinas.net/wp-content/uploads/2020/10/moto-razr-5g-and-moto-g-5g-plus.jpg?fit=1200%2C628&ssl=1",
                "description": "Add to Cart to See More!!!",
                "content": "The iconic flip phone is back with all the things you need! This phone’s premium design featuring precision-crafted metal and glass, along with the 15.74 cm (6.2) OLED foldable display, will make heads turn. The flexible material makes it all the more attractive and easy to handle, as you can just fold the phone and place it easily in your pocket,When you fold this phone, its 6.85 cm (2.75) Quick View display is all you need to stay connected without having to open your phone completely.With 8 GB of RAM and the Qualcomm Snapdragon 765G processor, this smartphone will give you a performance you can count on for all your phone-related tasks. This smartphone is 5G-ready as well! Oh, and it also features 256 GB of storage space so that you can store everything in one place.HD+ AMOLED Foldable Screen (pOLED) Display.Internal Display: 6.2 inch pOLED Foldable Display, 21:9 Screen Ratio, External Display: 2.7 inch Quick View gOLED Display, 4:3 Screen Ratio, Display Resolution: 876 x 2142 Pixels (Internal), 800 x 600 Pixels (External), Screen-to-body Ratio: 70.20% Active Area Touch Panel (AA-TP),48MP Sensor (Quad Pixel, 1.6um, f/1.7) + OIS + Laser Auto Focus, Rear Camera Software: Auto Smile Capture, Smart Composition, Shot Optimization, Night Vision, High-res Zoom, HDR, Timer, AR Stickers, Active Photos, Cinemagraph, Manual Mode, Portrait Mode, Cutout, Spot Color, Panorama, Live Filter, RAW Photo Output, Watermark, Burst Shot, Best Shot, Google Lens Integration, Rear Camera Video Software: Slow Motion Video, Timelapse Video, Spot Color Video,and much more....",
                "price": 124999,
                "colors":["orange","black","crimson","teal"],
                "count": 1
            }
        ],
        cart: [],
        total: 0
        
    };

    addCart = (id) =>{
        const {products, cart} = this.state;
        const check = cart.every(item =>{
            return item._id !== id
        })
        if(check){
            const data = products.filter(product =>{
                return product._id === id
            })
            this.setState({cart: [...cart,...data]})
        }else{
            alert("The product has been added to cart.")
        }
    };

    reduction = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item._id === id){
                item.count === 1 ? item.count = 1 : item.count -=1;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    increase = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item._id === id){
                item.count += 1;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    removeProduct = id =>{
        if(window.confirm("Do you want to delete this product?")){
            const {cart} = this.state;
            cart.forEach((item, index) =>{
                if(item._id === id){
                    cart.splice(index, 1)
                }
            })
            this.setState({cart: cart});
            this.getTotal();
        }
       
    };

    getTotal = ()=>{
        const{cart} = this.state;
        const res = cart.reduce((prev, item) => {
            return prev + (item.price * item.count);
        },0)
        this.setState({total: res})
    };
    
    componentDidUpdate(){
        localStorage.setItem('dataCart', JSON.stringify(this.state.cart))
        localStorage.setItem('dataTotal', JSON.stringify(this.state.total))
    };

    componentDidMount(){
        const dataCart = JSON.parse(localStorage.getItem('dataCart'));
        if(dataCart !== null){
            this.setState({cart: dataCart});
        }
        const dataTotal = JSON.parse(localStorage.getItem('dataTotal'));
        if(dataTotal !== null){
            this.setState({total: dataTotal});
        }
    }
   

    render() {
        const {products, cart,total} = this.state;
        const {addCart,reduction,increase,removeProduct,getTotal} = this;
        return (
            <DataContext.Provider 
            value={{products, addCart, cart, reduction,increase,removeProduct,total,getTotal}}>
                {this.props.children}
            </DataContext.Provider>
        )
    }
}


